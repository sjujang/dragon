// Example main mod class
package dragonweapons;

import net.minecraftforge.fml.common.Mod;

@Mod("dragonweapons")
public class DragonWeaponsMod {
    public DragonWeaponsMod() {
        // Initialize mod content
    }
}